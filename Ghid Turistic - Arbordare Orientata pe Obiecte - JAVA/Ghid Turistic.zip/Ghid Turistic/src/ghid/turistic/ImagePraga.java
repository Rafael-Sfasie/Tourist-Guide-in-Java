/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ghid.turistic;
import java.awt.*;
/**
 *
 * @author Rafael Sfasie
 */
public class ImagePraga extends java.applet.Applet{
    Image praga;
    @Override
    public void init(){
        praga=getImage(getCodeBase(),"Praga.jpg");
    }
    @Override
    public void paint(Graphics g){
        g.drawImage(praga, 20, 20, this);
    }
}
