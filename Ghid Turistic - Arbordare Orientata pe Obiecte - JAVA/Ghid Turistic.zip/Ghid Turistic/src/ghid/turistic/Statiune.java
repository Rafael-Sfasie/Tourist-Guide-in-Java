/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ghid.turistic;

/**
 *
 * @author Rafael Sfasie
 */
public class Statiune extends Oras{
    public Statiune(String N,int vizitors,int clasament){
        super(N,vizitors,clasament);
    }
    public void afisare(){
        System.out.println("Denumire: " + this.getDenumire() + "\nVizitatori: " + this.getVizitatori() + "\nLocul in Clasament: " + this.getClasament());
    }
}
