/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ghid.turistic;

/**
 *
 * @author Rafael Sfasie
 */
public class Munte extends Tara{
    private double altitudinea;
    public Munte(String N,int vizitors,int alt){
        super(N,vizitors);
        this.altitudinea=alt;
    }
    public double getAltitudinea(){
        return altitudinea;
    }
    public void setAltitudinea(double alt){
        this.altitudinea=alt;
    }
    public void afisare(){
        System.out.println("Denumire: " + this.getDenumire() + "\nVizitatori: " + this.getVizitatori() + "\nAltitudinea Maxima: " + this.altitudinea);
    }
}
