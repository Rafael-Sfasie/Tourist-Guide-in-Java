/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ghid.turistic;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author Rafael Sfasie
 */
public class GhidTuristic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String denumire = JOptionPane.showInputDialog("denumire=");
        String numeOras=JOptionPane.showInputDialog("Numele orasului: ");
        //Cehia
        if("Cehia".equals(denumire)){
            Tara country1 = new Tara("Cehia",1234890);
            country1.addAtraction("Praga");
            country1.addAtraction("\nLitomysl");
            country1.addAtraction("\nCastelul Karlstein");
            country1.addAtraction("\nMoravia");
            country1.addAtraction("\nBiesrica Oaselor");
            String[] atractii = country1.getAtraction();
            System.out.println("Denumire:" + country1.getDenumire() + "\nNrAtractiiTurustice: " + country1.getNrAtractii() + "\nNrVizitatoriAnuali: " + country1.getVizitatori());
            for(int i=0;i<country1.getNrAtractii();i++)
                System.out.print(atractii[i]);
            System.out.println("\n");
            if(numeOras.equals("Praga")){
                Oras city1 = new Oras("Praga",900456,21);
                city1.addAtraction("Ceasul astrnomic");
                city1.addAtraction("Podul Carol");
                city1.addAtraction("Casteul Regal");
                city1.addAtraction("Centrul vechi");
                city1.addAtraction("Casa care danseaza");
                String[] atractions = city1.getAtraction();
                System.out.println("Numele orasului: " + city1.getDenumire() + "\nNrAtracitiiTuristice: " + city1.getNrAtractii() + "\nNrVizitatori anuali: " + city1.getVizitatori() + "\nLocul in clasament: " + city1.getClasament());
                for(int i=0;i<city1.getNrAtractii();i++)
                    System.out.println(atractions[i]);
                System.out.println();
            }
            else if(numeOras.equals("Litomysl")){
                Oras city2=new Oras("Litomysl",621365,34);
                city2.addAtraction("Castelul Litomysl");
                city2.addAtraction("Muzeul regional Litomysl");
                city2.addAtraction("Portmoneum");
                city2.addAtraction("Gradinile manastiri Litomysl");
                String[] atractions2=city2.getAtraction();
                System.out.println("Numele orasului: " + city2.getDenumire());
                System.out.println("NrAtractiiTuristice: " + city2.getNrAtractii());
                System.out.println("NrVziztatoriAnuali: " + city2.getVizitatori());
                System.out.println("Locul in Clasament: " + city2.getClasament());
                for(int i=0;i<city2.getNrAtractii();i++)
                    System.out.println(atractions2[i]);
                System.out.println();
            }
            Biserica church1=new Biserica("Biserica oaselor",1200000,1400,"gotic");
            church1.afisare();
            System.out.println();
            Castel castle1 = new Castel("Castelul Karlstein",670456,1348);
            castle1.afisare();
            System.out.println();
            Statiune statiune1=new Statiune("Moravia",323145,39);
            statiune1.afisare();
        //Irlanda
        }
        else if(denumire.equals("Irlanda")){
            Tara country2=new Tara("Irlanda",3400000);
            country2.addAtraction("Dublin");
            country2.addAtraction("Stanca Cashel");
            country2.addAtraction("Castelul Bunratty");
            country2.addAtraction("Glendalough");
            String[] atractii2=country2.getAtraction();
            System.out.println("Denumire:" + country2.getDenumire() + "\nNrAtractiiTurustice: " + country2.getNrAtractii() + "\nNrVizitatoriAnuali: " + country2.getVizitatori());
            for(int i=0;i<country2.getNrAtractii();i++)
                System.out.println(atractii2[i]);
            System.out.println();
            Oras city3=new Oras("Dublin",1789342,14);
            city3.addAtraction("Trinity College");
            city3.addAtraction("Beararia Guiness");
            city3.addAtraction("Parcul Sfantul Stefan Verde");
            city3.addAtraction("Parlamentul Irlandez");
            String[] atraction3=city3.getAtraction();
            System.out.println("Denumire:" + city3.getDenumire() + "\nNrAtractiiTurustice: " + city3.getNrAtractii() + "\nNrVizitatoriAnuali: " + city3.getVizitatori() + "\nClasamentul Global: " + city3.getClasament());
            for(int i=0;i<city3.getNrAtractii();i++)
                System.out.println(atraction3[i]);
            System.out.println("\n");
            Biserica church2=new Biserica("Stanca Cashel",800000,356,"gotic");
            church2.afisare();
            System.out.println("\n");
            Castel castle2=new Castel("Castelul Bunratty",500000,1425);
            castle2.afisare();
            System.out.println("\n");
            Statiune statiune2=new Statiune("Glendalough",700000,8);
            statiune2.afisare();
        //Suedia
        }
        else if(denumire.equals("Suedia")){
            Tara country3=new Tara("Suedia",10000000);
            country3.addAtraction("Uppsala");
            country3.addAtraction("Castelul Kalmar");
            country3.addAtraction("Parcul National Korsterhavet");
            country3.addAtraction("Stockholm");
            country3.addAtraction("Catedrala din Lund");
            String[] atractii3=country3.getAtraction();
            System.out.println("Denumire:" + country3.getDenumire() + "\nNrAtractiiTurustice: " + country3.getNrAtractii() + "\nNrVizitatoriAnuali: " + country3.getVizitatori());
            for(int i=0;i<country3.getNrAtractii();i++)
                System.out.println(atractii3[i]);
            System.out.println();
            if(numeOras.equals("Stockholm")){
                Oras city4=new Oras("Stockholm",9563896,10);
                city4.addAtraction("Arhipelagul Stockholm");
                city4.addAtraction("Centrul vechi(Gamla Stan)");
                city4.addAtraction("Palatul Regal");
                city4.addAtraction("Muzeul Vasa");
                city4.addAtraction("Insula Djurgarden");
                String[] atractions4=city4.getAtraction();
                System.out.println("Denumire: " + city4.getDenumire());
                System.out.println("NrAtractiiTuristice: " + city4.getNrAtractii());
                System.out.println("NrVizitatori: " + city4.getVizitatori());
                System.out.println("Clasamentul Global: " + city4.getClasament());
                for(int i=0;i<city4.getNrAtractii();i++)
                    System.out.println(atractions4[i]);
                System.out.println();
            }
            else if(numeOras.equals("Uppsala")){
                Oras city5=new Oras("Uppsala",7128456,8);
                city5.addAtraction("Catedrala din Uppsala");
                city5.addAtraction("Muzeul Gustavianum");
                city5.addAtraction("Gamla Uppsala");
                city5.addAtraction("Universitatea din Uppsala");
                String[] atractions5=city5.getAtraction();
                System.out.println("Denumire: " + city5.getDenumire());
                System.out.println("NrAtractiiTuristice: " + city5.getNrAtractii());
                System.out.println("NrVizitatori: " + city5.getVizitatori());
                System.out.println("Clasamentul Global: " + city5.getClasament());
                for(int i=0;i<city5.getNrAtractii();i++)
                    System.out.println(atractions5[i]);
                System.out.println();
            }
            Biserica church2=new Biserica("Catedrala din lund",2000000,1234,"gotic");
            church2.afisare();
            System.out.println();
            Castel castle3 = new Castel("Castelul Kalmar",1345678,1200);
            castle3.afisare();
            System.out.println();
            Statiune statiune3=new Statiune("Parcul National Korsterhavet",900000,7);
            statiune3.afisare();
            System.out.println();
        }
        
        
    }
    
}
